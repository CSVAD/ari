package test.library;


import processing.core.*;
import java.lang.Math.*;

/**
 * This is a template class and can be used to start a new processing Library.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own Library naming convention.
 * 
 * (the tag example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 * @example Hello 
 */

public class Test {
	
	// myParent is a reference to the parent sketch
	PApplet myParent;
	
	float[] yvalues;
	float[] yvalues_cos;
	int xspacing = 1;

	
	public final static String VERSION = "1.0.0";
	

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the Library.
	 * 
	 * @example Hello
	 * @param theParent the parent PApplet
	 */
	public Test(PApplet theParent) {
		myParent = theParent;
		welcome();
	}
	
	
	private void welcome() {
		System.out.println("Your Library 1.0.0 by Your Name http://yoururl.com");
	}
	
	public void setUp(int width, int height, int amplitude, int period ) {
		double theta = 0.0;
		float dx;

		yvalues = new float[(width+16)/xspacing];
		yvalues_cos = new float[(width+16)/xspacing];
		
		int prev_amplitude = 0;
		
		for(int i = 0; i < height; i++) {
		    period += 10;
		    amplitude += 5;
			dx = (float)(myParent.TWO_PI/period)*xspacing;
			prev_amplitude += amplitude;
			calcWaves(amplitude+prev_amplitude, amplitude, dx, i+3);
			prev_amplitude+= amplitude;
		}

	}
	
	public void calcWaves(int h, int amplitude, double dx, int size) {
		  float x = (float)0.02;
		  float y = 1;
		  for (int i = 0; i < yvalues.length; i++) {
		    yvalues[i] = myParent.sin(x)*amplitude;
		    yvalues_cos[i] = myParent.cos(y)*amplitude;
		    x+=dx;
		    y+=dx;
		  }

		  myParent.noStroke();
		  myParent.fill(255);
		  // A simple way to draw the wave with an ellipse at each location
		  float min = myParent.min(yvalues);
		  float max = myParent.max(yvalues);

		  //test.waveSetUp(min, max, size, h);
		  for (int i = 0; i < yvalues.length; i++) {
			  myParent.fill(130, myParent.map(i, 0, yvalues.length, 0, 255), myParent.map(yvalues[i], min, max, 0, 360));
			  myParent.ellipse(i*xspacing, h+yvalues[i], size, size);
			  myParent.fill(130, myParent.map(i, 0, yvalues.length, 0, 255), myParent.map(yvalues[i], min, max, 0, 360));
			  myParent.ellipse(i*xspacing, h+yvalues_cos[i], size, size);
		  }
	}
//	public void waveSetUp(float min, float max, int size, float h, int i, float i_yvalues, float i_cosyvalues) {
//		  for (int i = 0; i < yvalues.length; i++) {
//			    myParent.fill(130, myParent.map(i, 0, yvalues.length, 0, 255), myParent.map(i_yvalues, min, max, 0, 360));
//			    myParent.ellipse(i*xspacing, h+i_yvalues, size, size);
//			    myParent.fill(130, myParent.map(i, 0, yvalues.length, 0, 255), myParent.map(i_yvalues, min, max, 0, 360));
//			    myParent.ellipse(i*xspacing, h+i_cosyvalues, size, size);
//			  }
		
//	}

}

